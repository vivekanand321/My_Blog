""" 
In this Project we are going to make a site which is having a bloging platform in it .
like blog we could add apps like personal consultnt,shopping cart etc.

# Creating a new Project/app:
    $ django-admin startproject mysite
    $ python manage.py startapp blog //this is for making an app name blog

"""